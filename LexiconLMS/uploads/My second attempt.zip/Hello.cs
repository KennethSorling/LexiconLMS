using System;
namespace Hello {
  public class Hello {
    public static void Main(){
	System.Out.PrintLn("Hello, World");
    }
  }
}
