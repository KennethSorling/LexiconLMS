﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Donjon
{
    internal class Monster
    {
        private string symbol = "M ";
        public string Symbol => symbol;

        public Monster()
        {

        }
    }
}
